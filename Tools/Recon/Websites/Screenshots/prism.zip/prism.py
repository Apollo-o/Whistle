# =================================================================================================================================================================================

# Built-in
import os
import time
import random

# Third-party
from tqdm import tqdm
from bs4 import BeautifulSoup
from html2image import Html2Image
import requests

# =================================================================================================================================================================================

# Filenames
name1 = "test.txt"
name2 = "list.txt"
name3 = "_.html"

# =================================================================================================================================================================================

# Get Screenshot
# Precondition: A Keyword
# Postcondition: A File
def screenshot(keyword):

    # Object, Time, and Delete
    hti     = Html2Image()
    seconds = time.time() * 1000
    delete  = [os.remove(i) for i in os.listdir() if i.endswith(".jpg")]

    # =================================================================================================================================================================================

    # Options
    temp    = []
    if keyword == "search":

        # Search
        search = input("Enter Search: ")
        page   = requests.get("https://www.google.dz/search?q={}".format(search))
        soup   = BeautifulSoup(page.content, "html.parser")
        links  = soup.findAll("a")

        # Get Links
        for i in links:

            if i.find("href=\"") != -1:
                check = str(i).split("http")[-1].split(">")[0]
                if check[0] == ":" or check[0] == "s":
                    temp.append("http" + check.strip("\""))

        # Save File
        random.seed(5)
        writer = open(name1, "w")
        for url_temp in tqdm(temp):

            # Screenshot
            print()
            url_temp = url_temp.split("&")[0]
            filename = "{}.jpg".format(random.random() + seconds)
            hti.screenshot(url=url_temp, save_as=filename)
            _ = os.system('cls')
            time.sleep(1.5)
            
            # HTML Line
            writer.write("<a href=\"{}\"><img src=\"{}\" alt=\"Snow\" style=\"width:100%\"></a>\n".format(url_temp,filename))

        writer.close()

    # =================================================================================================================================================================================

    elif keyword == "random":

        # Get Links
        page = requests.get("https://urlscan.io/sitemap")
        data = str(page.content).split("<a")

        # Extract Links
        temp  = []
        total = 50
        for d in data:
            if d.find("http") != -1:
                if d.find("title=\"") != -1:
                    url = d[d.find("title=\""):].split("</a>")[0].strip("title=\"").split(">")[0].strip("\"")
                    if len(url) < 100:
                        if d.find("//") != -1 and d != None:
                            try:
                                test = url.split("/")[2]
                                if len(test) > 2 and (not(test[0].isnumeric()) and not(test[-1].isnumeric())):
                                    temp.append(url)
                            except:
                                pass
        
        # Save File                   
        writer = open(name1, "w")
        random.seed(5)
        for url_temp in tqdm(random.choices(temp, k=50)):

            # Screenshot
            print()
            filename = "{}.jpg".format(random.random() + seconds).strip()
            hti.screenshot(url=url_temp.strip(), save_as=filename)
            print()
            _ = os.system('cls')
            time.sleep(2)
            
            # HTML Line
            if os.path.getsize(filename) > 20000:
                writer.write("<a href=\"{}\"><img src=\"{}\" alt=\"Snow\" style=\"width:100%\"></a>\n".format(url_temp.strip(),filename.strip()))

        writer.close()

    # =================================================================================================================================================================================

    if keyword == "file":

        # Open File
        reader = open(name2, "r")
        temp   = [i.strip() for i in reader.readlines()]
        reader.close()
        
        # Save File
        writer = open(name1, "w")
        random.seed(5)
        for url_temp in tqdm(temp):
            
            # Screenshot
            print()
            url_temp = "https://" + url_temp
            filename = "{}.jpg".format(random.random() + seconds)
            hti.screenshot(url=url_temp, save_as=filename)
            time.sleep(2)

            # HTML Line
            writer.write("<a href=\"{}\"><img src=\"{}\" alt=\"Snow\" style=\"width:100%\"></a>\n".format(url_temp,filename))

        writer.close()

# =================================================================================================================================================================================

# Create HTML
# Precondition: None
# Postcondition: A File
def html():

    # HTML Tags
    writer = open(name3,"w")
    writer.write("""

    <!DOCTYPE html>
    <html>
    <head>
    <style>
    * {
      box-sizing: border-box;
    }

    .column {
      float: left;
      width: 33.33%;
      padding: 5px;
    }

    /* Clearfix (clear floats) */
    .row::after {
      content: "";
      clear: both;
      display: table;
    }
    </style>
    </head>
    <body bgcolor="#000000">

    
    <div class="row">
                 """)

    # Temporary
    temp = []
    temp.append(["<div class=\"column\">"])
    temp.append(["<div class=\"column\">"])
    temp.append(["<div class=\"column\">"])

    # File
    reader = open(name1,"r")
    files  = list(set(reader.readlines()))
    reader.close()

    # Filter
    count = 0
    for i in tqdm(files):

        if i.find("google") == -1:
            if i.find("wikipedia") == -1:
                if i.find("aws") == -1:
                    temp[count].append(i)
                    count += 1

        if count == 3:
            count = 0

        time.sleep(0.5)
        print("\n")

    # Divide
    temp[0].append("</div>")
    temp[1].append("</div>")
    temp[2].append("</div>")

    # Columns
    writer.write("\n".join(temp[0]))
    writer.write("\n".join(temp[1]))
    writer.write("\n".join(temp[2]))
    writer.write("""

        </div>

    </body>
    </html>

    """)


# =================================================================================================================================================================================

# Start Program
screenshot("random")
time.sleep(30)
html()
