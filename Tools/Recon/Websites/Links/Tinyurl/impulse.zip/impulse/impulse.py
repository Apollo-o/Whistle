# Author: o-o
# Date: 4/14/2020
# Description: A Simple Script That Finds Urls.

import argparse
import random
import requests

# Save Data to a File.
# Precondition: Two Lists.
# Postcondition: A File.
def connect(http,https):

  # Read the File.
  reader = open("urls.txt","r")
  raw    = reader.read().split("\n")
  raw.pop()
  urls   = list(dict.fromkeys(raw))
  reader.close()

  # Create Session Object.
  session = requests.session()

  # Create Proxies.
  session.proxies = {"http":"http://{}:{}".format(http[0],http[-1]),"https":"https://{}:{}".format(https[0],https[-1])}

  # Create Request Header.
  header = {}
  header["User-Agent"]       = "Morzilla/7.0 (911; Pinux x86_128; rv:9743.0)"
  header["Accept"]           = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
  header["Accept-Languag"]   = "es-AR,en-US;q=0.7,en;q=0.3"
  header["Connection"]       = "close"

  # Security Tests.
  tests = ["http://httpbin.org/ip","http://httpbin.org/user-agent","http://httpbin.org/cookies"]

  # Start Tests.
  for test in tests:

    try:
      # Send request.
      session.cookies.clear()
      request = session.get(test,headers=header)
      print(request.text.split("\n")[1].strip(" "))
    except Exception as e:
      print("\"Failed\": " + test)

    # Write to a File.
    with open("200 OK.txt","w") as writer:

      # Get Status Code.
      for url in urls:

        try:
          # Send requests.
          session.cookies.clear()
          request = session.get(url,headers=header)

          # Status Code 200 OK.
          if request.status_code == 200:
            writer.write(url + "\n")
        except:
          continue

# Create a Text File.
# Precondition: An Integer.
# Postcondition: A File.
def create(amount):

  # Create Text File.
  with open("urls.txt","w") as writer:

    # Generate List.
    for element in range(amount):

      # Alphabet & Numbers.
      alphabet  = "abcdefghijklmnopqrstuvwxyz"
      numbers   = "0123456789"

      # Create Path.
      url       = "https://tinyurl.com/"
      path      = ""
      path_min  = 3
      path_max  = 8
      num_count = 0
      num_max   = 5
      for value in range(random.randint(path_min,path_max)):

        # Choose Random Value.
        value_type = random.randint(0,1)
        if value_type == 0 and num_count != num_max:
          path += numbers[random.randint(0,len(numbers)-1)]
          num_count += 1
        else:
          path += alphabet[random.randint(0,len(alphabet)-1)]

      # Write to the File (Webpages)
      writer.write("{}{}\n".format(url,path))

      # Write to the File (Files)
      if len(path) == 8:
        writer.write("{}y{}\n".format(url,path[1:]))

# Parse the Command.
# Precondition: None.
# Postcondition: Start Module.
def parse():

    try :

        # Create Object && Format.
        parser = argparse.ArgumentParser(add_help=False)

        # Group && Add Arguments.
        group1 = parser.add_argument_group("options")
        group2 = parser.add_argument_group("additional")
        group1.add_argument("-c",type=int,nargs=1,metavar='NUMBER',help=": Create the urls.")
        group1.add_argument("-t",type=str,nargs=2,metavar=('IP:PORT','IP:PORT'),help=": Test the urls.")
        group2.add_argument("-h",action="help",default=argparse.SUPPRESS,help=": Displays the usage screen.")

        # Join & Create Arguments.
        args = parser.parse_args()

        # If the Correct Command.
        if args.c:

            # Processing Data.
            create(args.c[0])
    
	elif args.t != None and len(args.t) == 2:

            # Check Colon && Check Port.
            error_message = "Incorrect Proxy Format."
            proxy_1 = args.t[0]
            proxy_2 = args.t[-1]
            if (proxy_1.find(":") != -1 and proxy_2.find(":") != -1) and (proxy_1.split(":")[-1].isdigit() and proxy_2.split(":")[-1].isdigit()):

                # Verify IP 1 && IP 2.
                ip_1 = proxy_1.split(":")[0]
                ip_2 = proxy_2.split(":")[0]

                if (ip_1.find(".") != -1 and ip_2.find(".") != -1):
                    
                    # IP Size.
                    size_1 = ip_1.split(".")
                    size_2 = ip_2.split(".")

                    # Check IP 1 && IP 2 Size.
                    if len(size_1) == 4 and len(size_2) == 4:

                        for num_1 in size_1:
                            if not(num_1.isdigit() and len(num_1) <= 3):
                                print(error_message)
                                quit()

                        for num_2 in size_2:
                            if not(num_2.isdigit() and len(num_2) <= 3):
                                print(error_message)
                                quit()

                        # Processing Data.
                        connect(args.t[0].split(":"),args.t[-1].split(":"))

                    else:
                        print(error_message)
                else:
                    print(error_message)
            else:
                print(error_message)
        else:
            parser.print_help()

    except Exception as e:
        print(str(e))

# Execute the program.
if __name__ == "__main__":
    parse()
