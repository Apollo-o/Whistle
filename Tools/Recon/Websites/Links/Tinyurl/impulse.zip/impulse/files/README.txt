Requests:

1. https://medium.com/@jasonrigden/using-tor-with-the-python-request-library-79015b2606cb
2. https://blog.scrapinghub.com/python-requests-proxy
3. https://free-proxy-list.net/